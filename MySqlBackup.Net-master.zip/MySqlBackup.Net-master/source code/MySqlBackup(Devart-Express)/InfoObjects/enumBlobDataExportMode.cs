﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Devart.Data.MySql
{
    public enum BlobDataExportMode
    {
        HexString = 1,
        BinaryChar = 2
    }
}
