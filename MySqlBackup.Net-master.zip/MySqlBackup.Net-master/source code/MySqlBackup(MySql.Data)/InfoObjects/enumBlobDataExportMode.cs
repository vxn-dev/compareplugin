﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MySql.Data.MySqlClient
{
    public enum BlobDataExportMode
    {
        HexString = 1,
        BinaryChar = 2
    }
}
