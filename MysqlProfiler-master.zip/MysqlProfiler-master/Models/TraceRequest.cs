﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MysqlProfiler.Models
{
    public class TraceRequest
    {
        public string Keyword { get; set; }
    }
}
