function getNotificationsElement() {
  const NOTIFICATIONS_ELEMENT_ID = "webhighlights-notifications";

  let notificationsDomElement = document.getElementById(
    NOTIFICATIONS_ELEMENT_ID
  );
  if (!notificationsDomElement) {
    notificationsDomElement = document.createElement("div");
    notificationsDomElement.id = NOTIFICATIONS_ELEMENT_ID;
    document.body.appendChild(notificationsDomElement);
  }
  return notificationsDomElement;
}
function dispatchWebHighlightsNotification(event, eventInitDict) {
  getNotificationsElement().dispatchEvent(
    new CustomEvent(event, eventInitDict)
  );
}
