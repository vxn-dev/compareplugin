// function initToggleSidebarButton() {
//   const toggleWebHighlightsSidebarElement = document.getElementById(
//     "toggleWebHighlightsSidebar"
//   );
//   const viewWebHighlightsSidebarElement = document.getElementById(
//     "viewWebHighlightsSidebar"
//   );
//   if (toggleWebHighlightsSidebarElement) {
//     toggleWebHighlightsSidebarElement.onclick = () => {
//       dispatchWebHighlightsNotification("toggleSidebar", {});
//     };
//   }
//   if (viewWebHighlightsSidebarElement) {
//     viewWebHighlightsSidebarElement.onclick = () => {
//       dispatchWebHighlightsNotification("toggleSidebar", {});
//     };
//   }
// }

// function initWebHighlightsLayout() {
//   setTimeout(() => {
//     initToggleSidebarButton();
//   });
// }

// initWebHighlightsLayout();
